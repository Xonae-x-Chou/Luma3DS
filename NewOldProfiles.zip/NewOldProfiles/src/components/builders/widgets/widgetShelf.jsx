import { useState, useLayoutEffect, useMemo, useRef } from 'react';
import { IconUtils } from '@modules/common';
import { NewGameStore } from '@modules/stores';
import { TooltipBuilder } from '@components/common/TooltipBuilder';
import { GameCover } from './common/gameCover';
import { FallbackCover } from './common/fallbackCover';

export function ShelfWidgetBuilder({ game, user }) {
    const [loading, setLoading] = useState(() => true);

    let imageURL = IconUtils.getGameAssetURL({id: game?.id, hash: game?.coverImage, size: "1024", keepAspectRatio: true});
    const image = useMemo(() => new Image(), []);

    const ref = useRef(null);

    useLayoutEffect(() => {
        if (!imageURL) imageURL = NewGameStore.getCoverImageUrl(game?.id);
        image.src = imageURL;
        
        if (!image.src) {
            setLoading(true);

            if (image.parentElement) image.parentElement.removeChild(image);

            return;
        }

        if (image.isConnected) return;

        image.onload = () => {
            setLoading(false);
        };

        return () => { delete image.onload; };
    }, [imageURL]);

    return (
        <div style={{ position: "relative" }} ref={ref}>
            <TooltipBuilder note={game?.name}>
                {loading ? <FallbackCover game={game} /> : <GameCover game={game} image={image} imageURL={imageURL} />}
            </TooltipBuilder>
        </div>
    )
}