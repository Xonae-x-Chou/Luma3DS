import { Data, Utils } from 'betterdiscord';
import { useState } from 'react';
import { IconUtils, ButtonClasses, ModalRoot, ModalSystem, RoleRenderer, RoleUpdater, Card, intl } from '@modules/common';
import { GuildMemberStore, GuildRoleStore, GuildStore } from '@modules/stores';
import { ConnectionComponent, MarkdownComponent, NoteComponent, BoardEditRenderer, RolePermissionHook } from '@modules/lazy';
import { locale } from '@common/locale';
import { FavoriteWidgetBuilder, ShelfWidgetBuilder, CurrentWidgetBuilder } from '@components/builders/widgets/index';
import { TooltipBuilder } from '@components/common/TooltipBuilder';

function SectionHeader({ children }) {
    return <div className="userInfoSectionHeader">{children}</div>
}

function MemberDateSupplementalBuilder({ date, member }) {
    return (
        <div 
            className={Utils.className("memberSince", member && "memberSinceServer")} 
            style={{ color: "var(--text-default)" }}>
                {
                    intl.intl.data.formatDate(new Date(date), {dateStyle: "medium"})
                }
        </div>
    )
}

function MemberDateIcon({ server }) {
    const [shouldFallback, setShouldFallback] = useState(false);
    
    return (
        <TooltipBuilder note={server.name}>
            {
                shouldFallback ? <div className="noIcon guildIcon" style={{ fontSize: "10px", backgroundImage: "none" }}>
                    <div className="acronym" >{server.name.substring(0, 1)}</div>
                </div>
                : <div className="guildIcon">
                    <img 
                        src={IconUtils.getGuildIconURL(server) + 'size=128'} 
                        style={{ borderRadius: "inherit", width: "inherit" }} 
                        onError={() => (setShouldFallback(true))}
                    />  
                </div>
            }
        </TooltipBuilder>
    )
}

function BoardButton({ user }) {
    return (
        <button
            className={`${ButtonClasses.button} ${ButtonClasses.sm} ${ButtonClasses.primary} ${ButtonClasses.hasText}`}
            onClick={() => ModalSystem.openModal((props) =>
                <ModalRoot.Modal {...props} title={locale.Strings.PROFILE_WIDGETS()}>
                    <BoardEditRenderer user={user} />
                </ModalRoot.Modal>
            )}>
            <div className={`${ButtonClasses.buttonChildrenWrapper}`}>
                <div className={`${ButtonClasses.buttonChildren}`} style={{ fontSize: "14px" }}>{locale.Strings.EDIT()}</div>
            </div>
        </button>
    )
}

export function PronounsBuilder({ displayProfile }) {
    return (
        <div className="userInfoSection">
            <SectionHeader>{locale.Strings.PRONOUNS()}</SectionHeader>
            <div className="userPronouns" style={{ color: "var(--text-default)", fontSize: "14px" }}>{displayProfile.pronouns}</div>
        </div>
    )
}

export function BioBuilder({ displayProfile }) {
    if (!displayProfile._userProfile.bio) return;
    return (
        <div className="userInfoSection">
            <SectionHeader>{locale.Strings.ABOUT_ME()}</SectionHeader>
            <MarkdownComponent 
                userBio={
                    displayProfile?._guildMemberProfile?.bio && Data.load('serverBio') ? displayProfile.bio
                    : displayProfile._userProfile.bio
                }
            /> 
        </div>
    )
}

export function RoleBuilder({ user, data }) {
    if (!data?.guildId || !Data.load('showRoles')) return;
    const serverMember = GuildMemberStore.getMember(data?.guildId, user.id);
    if (!serverMember || serverMember?.roles?.length === 0) {
        return;
    }
    const memberRoles = serverMember.roles?.map(role => GuildRoleStore.getRole(data?.guildId, role))
    return (
        <div className="userInfoSection">
            <SectionHeader>
                {
                    serverMember?.roles?.length !== 1 ? locale.Strings.ROLES()
                    : locale.Strings.ROLE()
                }
            </SectionHeader>
            <RoleRenderer 
                userId={user.id} 
                roles={memberRoles} 
                guild={GuildStore.getGuild(data?.guildId)} 
                className="rolesList" 
                allowEditing={RolePermissionHook({guildId: data.guildId}).canRemove}
            />
        </div>
    )
}

export function MemberDateBuilder({ data, user }) {
    const server = GuildStore.getGuild(data?.guildId);
    const serverMember = GuildMemberStore.getMember(data?.guildId, user.id);
    const serverDate = new Date(serverMember?.joinedAt);

    return (
        <div className="userInfoSection">
            <SectionHeader>{user.bot ? locale.Strings.CREATED_ON() : locale.Strings.MEMBER_SINCE()}</SectionHeader>
            <div className="memberSinceWrapper" style={{ display: "flex", gap: "8px", alignItems: "center" }}>
                <MemberDateSupplementalBuilder date={user.createdAt} />
                {data?.guildId && serverMember &&
                    <>
                        <div className="divider" />
                        <MemberDateIcon server={server} />
                        <MemberDateSupplementalBuilder date={serverDate} member={serverMember} />
                    </>
                }
            </div>
        </div>
    )
}

export function NoteBuilder({ user }) {
    return (
        <div className="userInfoSection">
            <SectionHeader>{locale.Strings.NOTE()}</SectionHeader>
            <NoteComponent userId={user.id} />
        </div>
    )
}

export function BoardButtonBuilder({ user }) {
    return (
        <div className="userInfoSection" style={{ paddingBottom: "20px" }}>
            <SectionHeader>{locale.Strings.PROFILE_WIDGETS()}</SectionHeader>
            <BoardButton user={user} />
        </div>
    )
}

export function BoardBuilder({widget, header, games, user}) {
    return (
        <div className="userInfoSection">
            <SectionHeader>{header}</SectionHeader>
            {widget.type.includes("favorite_games") &&
                <FavoriteWidgetBuilder widget={widget} game={games[0]} user={user} />
            }
            {(widget.type.includes("played_games") || widget.type.includes("want_to_play_games")) &&
                <div className="widgetCoverList">
                    {
                        widget.games.map((game, index) => <ShelfWidgetBuilder game={games[index]} user={user} />)
                    }
                </div>
            }
            {widget.type.includes("current_games") &&
                <div className="cardList">
                    {
                        widget.games.map((game, index) => <CurrentWidgetBuilder widget={widget} game={games[index]} index={index} user={user} />)
                    }
                </div>
            }
        </div>
    )
}

export function ConnectionCards({ user, connections }) {
    if (connections.length == 0) return;
    return (
        <div className="userInfoSection" style={{ borderTop: "1px solid var(--background-modifier-accent, var(--background-mod-normal))" }}>
            <div className="connectedAccounts">
                {connections.map(connection => <ConnectionComponent connectedAccount={connection} userId={user.id} />)}
            </div>
        </div>
    )
}

export function PrivateProfileNotice({ username }) {
    return (
        <div className="userInfoSection">
            <Card messageType="info" key="info">
                {locale.Strings.PRIVATE_PROFILE_WARNING({username})}
            </Card>
        </div>
    )
}