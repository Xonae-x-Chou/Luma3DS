export const settings = {
    main: {
        showGuildTag: {
            name: "Show user guild tag",
            note: "Displays a user's guild tag on their profile.",
            initial: true,
        },
        disableDiscrim: {
            name: "Disable discriminators",
            note: "Don't like legacy discriminators? This will always display a user's modern @ tag.",
            initial: false,
        },
        disableProfileThemes: {
            name: "Disable profile themes",
            note: "Disable a user's custom nitro profile colors.",
            initial: false,
        },
        disableRichBadges: {
            name: "Disable changing badge visuals",
            note: "Disable making badges white to match the rest of the profile header when a rich presence is active.",
            initial: false
        },
        boardTab: {
            name: "Board Tab",
            note: `If a user has game widgets, a "Board" tab will appear on the user profile. To edit your own widgets, press the button found under the "Profile Widgets" category on your profile.`,
            initial: false,
        }
    },
    serverCategory: {
        showRoles: {
            name: "Show member roles",
            note: "When viewing a user's profile in a server, that user's roles will be visible in the user's profile details.",
            initial: true,
        },
        serverBio: {
            name: "Show server about me",
            note: "When viewing a user's profile in a server, that user's custom about me will be displayed instead of their default one.",
            initial: true,
        },
    },
    default: {
        showGuildTag: true,
        disableDiscrim: false,
        disableProfileThemes: false,
        disableRichBadges: false,
        boardTab: false,
        showRoles: true,
        serverBio: true,
    }
};